# meta learning algorithm
from pretrain import pretrain_ours
from pretrain import linear_evaluation
from pretrain import pretrain_ssl

def get_algorithm(name):
    return globals()[name]